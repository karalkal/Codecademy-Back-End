import NewEditorButton from "./components/NewEditorButton"

const TopbarNewEditorButtonPlugin = () => ({
  components: {
    TopbarNewEditorButton: NewEditorButton,
  }
})

export default TopbarNewEditorButtonPlugin
