'use strict';


/**
 * GET all orders
 * Retrieve all orders info from orders.json
 *
 * no response value expected for this operation
 **/
exports.getOrders = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

