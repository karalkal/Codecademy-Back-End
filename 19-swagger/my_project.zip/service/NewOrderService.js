'use strict';


/**
 * POST new order
 * Adds new order to orders.json
 *
 * body Order  (optional)
 * no response value expected for this operation
 **/
exports.addOrder = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

