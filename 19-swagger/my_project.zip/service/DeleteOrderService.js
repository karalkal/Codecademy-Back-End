'use strict';


/**
 * DELETE order by id
 * Delete an order with a matching id from orders.json
 *
 * id String The id of the order.
 * no response value expected for this operation
 **/
exports.deleteOrder = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

